from django.db import models
from django.contrib.auth.models import User
from ckeditor.fields import RichTextField

class Giftcard_category(models.Model):
    title = models.CharField(max_length=30, null=False)
    slug = models.CharField(max_length=30, null=False)
    image = models.ImageField(upload_to = 'upload/images/' , null=False)


    def __str__(self):
        return self.title



class Giftcard(models.Model):
    name = models.CharField(max_length=100 , null=False)
    denomination_range = models.CharField(max_length=100 , null=False)
    payment_modes = RichTextField(null=False, default='')
    description = RichTextField(null=False)
    section = models.CharField(
        max_length=20,
        null = False,
        default='hidden_products',
        choices=[
            ('top_deals', 'Top Deals'),
            ('hidden_products', 'Hidden Products'),
            ('top_offers', 'Top Offers'),
        ]
    )
    Product_status = models.CharField( 
        max_length=20, 
        null=False ,
        default='active',         
        choices=[
            ('active', 'Active Product'),
            ('inactive', 'InAcive Product'),
        ])
    terms = RichTextField(null=False)
    howtoredeem = RichTextField(null=False)
    discount = models.IntegerField(default=0)
    image = models.ImageField(upload_to= 'upload/images/' , null=False)
    Giftcard_category = models.ForeignKey(Giftcard_category , on_delete=models.CASCADE)


    def __str__(self):
        return self.name
    


    


class Giftcard_Denomination(models.Model):
    Denominations = (
        ( '50' , "50" ),
        ( '100' , "100" ),
        ( '150' , "150" ),
        ( '200' , "200" ),
        ( '250' , "250" ),
        ( '300' , "300" ),
        ( '350' , "350" ),
        ( '400' , "400" ),
        ( '450' , "450" ),
        ( '500' , "500" ),
        ( '1000' , "1000" ),
        ( '1100' , "1100" ),
        ( '1200' , "1200" ),
        ( '1300' , "1300" ),
        ( '1400' , "1400" ),
        ( '1500' , "1500" ),
        ( '1600' , "1600" ),
        ( '1700' , "1700" ),
        ( '1800' , "1800" ),
        ( '1900' , "1900" ),
        ( '2000' , "2000" ),
        ( '2100' , "2100" ),
        ( '2200' , "2200" ),
        ( '2300' , "2300" ),
        ( '2400' , "2400" ),
        ( '2500' , "2500" ),
        ( '2600' , "2600" ),
        ( '2700' , "2700" ),
        ( '2800' , "2800" ),
        ( '2900' , "2900" ),
        ( '3000' , "3000" ),
        ( '3500' , "3500" ),
        ( '4000' , "4000" ),
        ( '4500' , "4500" ),
        ( '5000' , "5000" ),
        ( '5500' , "5500" ),
        ( '6000' , "6000" ),
        ( '6500' , "6500" ),
        ( '7000' , "7000" ),
        ( '7500' , "7500" ),
        ( '8000' , "8000" ),
        ( '8500' , "8500" ),
        ( '9000' , "9000" ),
        ( '9500' , "9500" ),
        ( '10000' , "10000" ),
    )
    price = models.IntegerField(null= False)
    Giftcard = models.ForeignKey(Giftcard , on_delete= models.CASCADE)
    Denomination = models.CharField(choices = Denominations , max_length=50)

class Profile(models.Model):
    user = models.OneToOneField(User , on_delete=models.CASCADE)
    Mobile_No = models.IntegerField()
    dob = models.DateField(null=True , blank=True)
    address_line_1 = models.CharField(max_length=10000 , null=True, blank=True)
    address_line_2 = models.CharField(max_length=10000 , null=True, blank=True)
    city = models.CharField(max_length=1000 , null=True, blank=True)
    state = models.CharField(max_length=1000 , null=True, blank=True)
    postal_code = models.CharField(max_length=10 , null=True, blank=True)
    added_on = models.DateTimeField(auto_now_add=True , null=True)
    update_on = models.DateTimeField(auto_now=True , null=True)

    def __str__(self):
        return f'{self.user.username} Profile'
    

class Carousel(models.Model):
    slider_image = models.ImageField(upload_to='upload/slider_images/')
    redirection_url = models.CharField(null=True , max_length=10000 , blank = True , default='/')
    Assign_giftcard = models.OneToOneField(Giftcard , on_delete=models.CASCADE , null=True , blank = True)

    def __str__(self):
        return f"Slider Image {self.id}"

class BrandsCarousel(models.Model):
    brand_name = models.CharField(null=False , max_length=100 , default='')
    brand_logo = models.ImageField(upload_to='upload/brand_logos/')
    assign_giftcard = models.OneToOneField(Giftcard , on_delete=models.CASCADE , null=True , blank = True)

    def __str__(self):
        return self.brand_name


class Web_logos(models.Model):
    Logo_name = models.CharField(null=False , max_length=100 , default='main_logo')
    main_logo = models.ImageField(upload_to='upload/website_logos/')
    contact_mail_logo = models.ImageField(null=True ,upload_to='upload/website_logos/')
    contact_no_logo = models.ImageField(null=True ,upload_to='upload/website_logos/')
    address_logo = models.ImageField(null=True ,upload_to='upload/website_logos/')

    def __str__(self):
        return self.Logo_name
    
class Web_contact_info(models.Model):
    contact_mail = models.EmailField(null = True)
    contact_No = models.IntegerField()
    office_address = models.CharField(null=True , max_length=1500 , default='')
    
    def __str__(self):
        return self.contact_mail

