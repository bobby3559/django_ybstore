from django.contrib import admin
from django.urls import path
from ybstore.views import *
from django.contrib.auth import views as auth_views

urlpatterns = [
    path( '' , home , name="home"),
    path('login/' , login , name="login"),
    path('profile/' , profile , name="profile"),
    path('edit_profile/' , edit_profile , name="edit_profile"),
    path('account/' , account , name="account"),
    path('signup/' , register , name="register"),
    path('logout/' , logout , name="logout"),
    path('giftcard/<int:giftcard_id>' , giftcard_details , name="giftcard_details"),
    path('giftcard_category/<int:category_id>/', giftcard_category, name='giftcard_category'),
    path('contactus/', Contact_Us, name='contactus'),
    path('terms_conditions/', TermsConditions, name='TermsConditions'),
    path('privacypolicy/', PrivacyPolicy, name='PrivacyPolicy'),
    

    # forgot password code

    path('password_reset/', auth_views.PasswordResetView.as_view(template_name='store/password_reset_form.html'), name='password_reset'),
    path('password_reset_done/', auth_views.PasswordResetDoneView.as_view(template_name='store/password_reset_done.html'), name='password_reset_done'),
    path('password_reset_confirm/<uidb64>/<token>/',auth_views.PasswordResetConfirmView.as_view(template_name='store/password_reset_confirm.html'), name='password_reset_confirm'),
    path('password_reset_complete/', auth_views.PasswordResetCompleteView.as_view(template_name='store/password_reset_complete.html'), name='password_reset_complete'),


    # change password code
    path('change_password/',auth_views.PasswordChangeView.as_view(template_name='store/change_password.html'), name='change_password'),
    path('password_change_done/',auth_views.PasswordChangeDoneView.as_view(template_name='store/password_change_done.html'), name='password_change_done'),
    path('product-list' , productlistAjax , name='search-giftcards'),
    path('searchgiftcard' , searchgiftcard , name='searchgiftcard'),
    



    
]
